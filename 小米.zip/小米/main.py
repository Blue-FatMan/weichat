# -*- coding: utf-8 -*-
import os
import sys
import time
import subprocess
from auto_adb import auto_adb
import random

import numpy as np
import pandas as pd

# df = pd.read_excel('filter.xlsx')
# net_time = np.array(df['入网时长'])  # 获取入网时长

adb = auto_adb()

dist_dict = {
    '0': [359, 1213],
    '1': [193, 882],
    '2': [359, 882],
    '3': [521, 882],
    '4': [193, 999],
    '5': [359, 999],
    '6': [521, 999],
    '7': [193, 1102],
    '8': [359, 1102],
    '9': [521, 1102],
}


def random_number():
    global number1
    global number2
    number1 = random.randint(1, 15)
    number2 = random.randint(1, 20)


def change_postion(x1, y1):
    random_number()  # 生成随机数,防止被封
    cmd = 'shell input tap {x1} {y1}'.format(x1=x1 + number1, y1=y1 + number2)  # 点击"搜索""
    print('{}'.format(cmd))
    adb.run(cmd)


def input_text(content):
    print(content)
    # cmd = 'shell am broadcast -a ADB_INPUT_TEXT --es msg \'{content}\''.format(content=content.decode("unicode_escape"))
    # cmd = 'shell am broadcast -a ADB_INPUT_TEXT --es msg \'{content}\''.format(content=content)
    time.sleep(2)
    cmd = 'shell input text {}'.format(content)
    print('{}'.format(cmd))
    adb.run(cmd)


def clean_text():
    t = 0
    cmd = 'shell input keyevent 67'  # 清空验证信息
    while (t < 10):
        print('{}'.format(cmd))
        adb.run(cmd)
        t += 1


# 截取当前屏幕的截图
def pull_screenshot():
    process = subprocess.Popen('adb shell screencap -p', shell=True, stdout=subprocess.PIPE)
    screenshot = process.stdout.read()
    if sys.platform == 'win32':
        screenshot = screenshot.replace(b'\r\n', b'\n')
    f = open('wechat.png', 'wb')
    f.write(screenshot)
    f.close()


def add_friend(mobile):
    print("正在添加...")
    change_postion(653, 94)  # 点击"+"号
    time.sleep(random.randint(2, 5))
    change_postion(457, 285)  # 点击"添加朋友"
    time.sleep(random.randint(2, 5))
    change_postion(313, 229)  # 点击输入栏
    time.sleep(random.randint(2, 5))
    # input_text(mobile)  # 输入对方手机/微信号
    print("正在搜索手机号：{}".format(mobile))
    change_postion(165, 1213)  # 点击输入法，切换为数字键盘
    # ------- 开始输入手机号 ----------
    for no in mobile:
        change_postion(dist_dict.get(no)[0], dist_dict.get(no)[1])
        time.sleep(random.randint(1, 2))
    # ------- 结束输入手机号 ----------
    change_postion(330, 207)  # 点击"搜索""
    time.sleep(random.randint(2, 5))  # 延迟0.5s,防止没加载出来
    change_postion(349, 713)  # 添加到微信通信录
    time.sleep(random.randint(2, 5))
    change_postion(653, 94)  # 发送加好友请求
    time.sleep(random.randint(2, 5))
    print("发送成功")
    change_postion(39, 94)  # 回退
    time.sleep(random.randint(0, 1))
    change_postion(39, 94)  # 回退
    time.sleep(random.randint(0, 1))
    change_postion(39, 94)  # 回退
    time.sleep(random.randint(0, 1))
    change_postion(39, 94)  # 回退
    time.sleep(random.randint(1800, 3000))


# pull_screenshot()

if __name__ == '__main__':
    # add_friend('18434391822')
    add_friend('17634985281')
    # add_friend('01234567890')

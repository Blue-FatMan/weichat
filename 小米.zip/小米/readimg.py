from PIL import Image
import matplotlib.pyplot as plt

print("输入图片路径")
img_input = input('>>')

img = Image.open(img_input)

plt.imshow(img)
plt.show()

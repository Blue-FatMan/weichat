# Wechat_addfriend
自动微信加好友，目前验证信息和备注只支持英语。
# 使用文件
auto_adb 来自 https://github.com/wangshub/wechat_jump_game
